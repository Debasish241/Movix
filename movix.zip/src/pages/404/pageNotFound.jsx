import React from 'react'
import "./style.scss"
const pageNotFound = () => {
  return (
    <div>
      
    </div>
  )
}
import "./style.scss"
export default pageNotFound
